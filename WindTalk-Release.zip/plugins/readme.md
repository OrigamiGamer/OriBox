# 以下文件名必须与DLL内 information 函数下所填写的插件信息一致！
- 插件包名
- dll文件名 (注意: 后缀名要写成".wt.dll")